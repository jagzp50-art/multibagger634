# Sportking India Limited (SPORTKING.NS) - Investment Report
**Date:** 14-Aug-2026 | **Price:** 199.89 | **M.Cap:** 1,490 Cr

## 1. 8-Point Checklist
| Criterion | Threshold | Actual | Status |
| :--- | :--- | :--- | :--- |
| **Market Cap** | > 1,000 Cr | 1490 Cr | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]">PASS</span> |
| **Valuation (PE)** | < 25 | 15.76 | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]">PASS</span> |
| **Efficiency (ROE)** | > 15% | 11.45% | <span class="px-2 py-0.5 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-black tracking-widest uppercase">FAIL</span> |
| **Debt / Equity** | < 0.5 | 0.58 | <span class="px-2 py-0.5 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-black tracking-widest uppercase">FAIL</span> |
| **Cash Quality** | CFO > PAT | 1.81 | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]">PASS</span> |
| **Momentum** | < 25% Drop | -17.23% | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]">PASS</span> |
| **Sales Growth** | > 10% | 6.2% | <span class="px-2 py-0.5 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-black tracking-widest uppercase">FAIL</span> |
| **EPS Growth** | > 0% | 115.9% | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]">PASS</span> |

## 2. Analyst Consensus
**Recommendation:** STRONG BUY (Based on 35 Analysts)

| Metric | Value |
| :--- | :--- |
| **Target Price (Avg)** | 150.00 |
| **Upside Potential** | -24.96% |
| **Number of Analysts**| 35 |

## 3. Financial Health Snapshot
| Metric | Value | Comment |
| :--- | :--- | :--- |
| **Profit Margin** | 6.2% | Low |
| **Quick Ratio** | N/A | Liquid Assets vs Liabilities |
| **Current Ratio** | N/A | Short term solvency |

## 4. Shareholding Pattern
| Holder Category | % Holding |
| :--- | :--- |
| **Insiders/Promoters** | 79.53% |
| **Institutions** | 0% |
| **Public/Others** | 20.47% |

## 5. Red Flags & Governance
| Risk Category | Score (1=Low, 10=High) | Status |
| :--- | :--- | :--- |
| **Overall ISS Risk** | N/A | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]"> OK</span> |
| **Audit Risk** | N/A | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]"> OK</span> |
| **Board Risk** | N/A | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]"> OK</span> |
| **Shareholder Rights** | N/A | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]"> OK</span> |
| **Short Interest Float** | N/A% | <span class="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black tracking-widest uppercase shadow-[0_0_10px_rgba(16,185,129,0.2)]"> OK</span> |

---
*Auto-generated quantitative report. Not financial advice.*
